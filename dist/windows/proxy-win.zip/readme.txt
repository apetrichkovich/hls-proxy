==========================================================================================
install-proxy.bat - установка и запуск прокси
uninstall-proxy.bat - остановка и удаление прокси
nssm.exe - менеджер для установки прокси в виде Windows сервиса с сайта https://nssm.cc
proxy-win.exe - прокси сервис
==========================================================================================
install-proxy.bat - install & start proxy
uninstall-proxy.bat - stop & uninstall proxy
nssm.exe - manager for proxy installing as Windows service from website https://nssm.cc
proxy-win.exe - proxy service
==========================================================================================